<?php

return [
	//Titles
	"title_index" => "Dashboard",
	"title_add" => "Agregar dashboard",
	"title_show" => "Ver dashboard",
	"title_edit" => "Modificar dashboard",
];
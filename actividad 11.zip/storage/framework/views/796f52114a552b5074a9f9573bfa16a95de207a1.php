
<?php $__env->startSection('datatable'); ?>
	<?php echo e($dataTable->table(["width" => "100%"])); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud-maker.layouts.index', [
	'title' => __('users.title_index'), 
	'entity' => 'users', 
	'form' => 'user',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/users/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('header'); ?>
	<h4 class="pb-1">
		<?php echo app('translator')->get('auth.register_title'); ?>
	</h4>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
	<form method="POST" action="<?php echo e(route('register')); ?>">
		<?php echo csrf_field(); ?>
		
		<?php echo $__env->make('auth.register-row', ['name' => 'name', 'type' => 'text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('auth.register-row', ['name' => 'paternal_surname', 'type' => 'text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('auth.register-row', ['name' => 'maternal_surname', 'type' => 'text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('auth.register-row', ['name' => 'email', 'type' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('auth.register-row', ['name' => 'password', 'type' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('auth.register-row', ['name' => 'password_confirmation', 'type' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="row mb-4">
			<div class="col-12 col-md-6">
				<button type="submit" class="btn btn-primary w-100" style="background-color: black;">
					<?php echo app('translator')->get('auth.button_register'); ?>
				</button>
			</div>
			<div class="col-12 col-md-6">
				<a href="<?php echo e(route("login")); ?>">
				<button type="button" class="btn btn-secondary w-100">
					<?php echo app('translator')->get('auth.button_cancel'); ?>
				</button>
				</a>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', ['floatingIcon' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/auth/register.blade.php ENDPATH**/ ?>
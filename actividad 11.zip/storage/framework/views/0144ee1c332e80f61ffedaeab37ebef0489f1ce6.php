<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

	<div data-simplebar class="h-100">

		<!--- Sidemenu -->
		<div id="sidebar-menu">
			<ul class="metismenu list-unstyled" id="side-menu">
				<?php echo $__env->make('components.theme.sidebar-menus', compact('menus'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</ul>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/components/theme/sidebar.blade.php ENDPATH**/ ?>
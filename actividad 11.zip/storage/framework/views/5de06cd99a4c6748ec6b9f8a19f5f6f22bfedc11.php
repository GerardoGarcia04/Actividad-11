<!DOCTYPE html>
<html lang="<?php echo e(setLocale(LC_ALL, env('APP_LOCALE'))); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo e((isset($title) ? $title." - " : "").config('app.name')); ?></title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meta name="app-url" content="<?php echo e(config('app.url')); ?>">
	
	<?php echo $__env->make('components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body data-sidebar="dark">
	<!-- Site wrapper -->
	<div id="layout-wrapper">
		<?php echo $__env->make('components.theme.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('components.theme.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<div class="main-content">
			<div class="page-content">
				<div class="container-fluid">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
			</div>
			<?php echo $__env->make('components.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>

		<?php echo $__env->make('components.theme.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</body>
<?php echo $__env->make('components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</html>
<?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/layouts/app.blade.php ENDPATH**/ ?>
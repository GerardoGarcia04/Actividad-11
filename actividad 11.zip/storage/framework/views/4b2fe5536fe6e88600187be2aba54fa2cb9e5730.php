

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-12">
			<input type="hidden" id="allowAdd" value="<?php echo e($allowAdd ?? false); ?>">
			<input type="hidden" id="allowEdit" value="<?php echo e($allowEdit ?? false); ?>">
			<input type="hidden" id="entity" value="<?php echo e($entity); ?>">
			<input type="hidden" id="form" value="<?php echo e($form); ?>">
			<?php echo $__env->yieldContent('data'); ?>

			<div class="row pt-4">
				<div class="col-12 col-md-10">
					<h3 class="pl-3"><?php echo e($title); ?></h3>
				</div>
				
			</div>
			
			<div class="row ">
				<div class="col-12 px-4">
					<?php echo $__env->yieldContent('filters'); ?>
				</div>
			</div>
			<div id="message" class="row  flex-shrink-0 flex-row ">
				<div class="col-12">
					<div class="message-container"></div>
					<?php echo $__env->make('crud-maker.components.session-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<?php echo $__env->yieldContent('datatable'); ?>
				</div>
			</div>
		</div>
	</div>

	<?php echo $__env->make('crud-maker.components.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<?php echo e($dataTable->scripts()); ?>

	<?php echo $__env->yieldPushContent('customScripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividad-9\resources\views/crud-maker/layouts/index.blade.php ENDPATH**/ ?>
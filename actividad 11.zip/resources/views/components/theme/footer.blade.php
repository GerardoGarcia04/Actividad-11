<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				Deiseño de aplicaciones web 2024
			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
					Actividad creada por: Gerardo Ivan Garcia Leon
				</div>
			</div>
		</div>
	</div>
</footer>